const db = require('../models');
const User = db.User;
const Bootcamp = db.Bootcamp;

// Crear y guardar un nuevo Bootcamp
exports.createBootcamp = (req, res) => {
    // Validar que el cuerpo de la solicitud no esté vacío
    if (!req.body.title || !req.body.cue || !req.body.description) {
        res.status(400).send({
            message: "El contenido no puede estar vacío!",
        });
        return;
    }

    // Crear un Bootcamp
    const bootcamp = {
        title: req.body.title,
        cue: req.body.cue,
        description: req.body.description
    };

    // Guardar el Bootcamp en la base de datos
    Bootcamp.create(bootcamp)
        .then(data => {
            res.send(data);
        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Ocurrió un error al crear el Bootcamp."
            });
        });
};

// Agregar un usuario a un Bootcamp
exports.addUser = (req, res) => {
    const bootcampId = req.body.bootcampId;
    const userId = req.body.userId;

    return Bootcamp.findByPk(bootcampId)
        .then((bootcamp) => {
            if (!bootcamp) {
                res.status(404).send({ message: "No se encontró el Bootcamp!" });
                return;
            }
            return User.findByPk(userId).then((user) => {
                if (!user) {
                    res.status(404).send({ message: "No se encontró el usuario!" });
                    return;
                }
                bootcamp.addUser(user);
                res.send(`>> Agregado el usuario id=${user.id} al bootcamp id=${bootcamp.id}`);
            });
        })
        .catch((err) => {
            res.status(500).send({
                message: "Error al agregar usuario al bootcamp"
            });
        });
};

// Obtener los usuarios de un Bootcamp por su ID
exports.findById = (req, res) => {
    const id = req.params.id;
    return Bootcamp.findByPk(id, {
        include: [{
            model: User,
            as: "users",
            attributes: ["id", "firstName", "lastName"],
            through: {
                attributes: [],
            }
        },],
    })
        .then((bootcamp) => {
            res.send(bootcamp);
        })
        .catch((err) => {
            res.status(500).send({
                message: "Error al obtener el Bootcamp con id=" + id
            });
        });
};

// Obtener todos los Bootcamps incluyendo sus usuarios
exports.findAll = (req, res) => {
    return Bootcamp.findAll({
        include: [{
            model: User,
            as: "users",
            attributes: ["id", "firstName", "lastName"],
            through: {
                attributes: [],
            }
        },],
    })
        .then((bootcamps) => {
            res.send(bootcamps);
        })
        .catch((err) => {
            res.status(500).send({
                message: err.message || "Ocurrió un error al obtener los Bootcamps."
            });
        });
};