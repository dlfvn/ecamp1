const db = require('../models');
const User = db.User;
const Bootcamp = db.Bootcamp;

// Crear y Guardar Usuarios
exports.createUser = (req, res) => {
  // Validar que el cuerpo de la solicitud no esté vacío
  if (!req.body.firstName || !req.body.lastName || !req.body.email) {
    res.status(400).send({
      message: "El contenido no puede estar vacío!",
    });
    return;
  }

  // Crear un usuario
  const user = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
  };

  // Guardar el usuario en la base de datos
  User.create(user)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Ocurrió un error al crear el usuario."
      });
    });
};

// Obtener los Bootcamp de un usuario por su ID
exports.findUserById = (req, res) => {
  const id = req.params.id;

  User.findByPk(id, {
    include: [
      {
        model: Bootcamp,
        as: "bootcamps",
        attributes: ["id", "title"],
        through: {
          attributes: [],
        },
      },
    ],
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `No se encontró el usuario con id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error al obtener el usuario con id=" + id
      });
    });
};

// Obtener todos los usuarios incluyendo sus Bootcamp
exports.findAll = (req, res) => {
  User.findAll({
    include: [
      {
        model: Bootcamp,
        as: "bootcamps",
        attributes: ["id", "title"],
        through: {
          attributes: [],
        },
      },
    ],
  })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Ocurrió un error al obtener los usuarios."
      });
    });
};

// Actualizar un usuario por su ID
exports.updateUserById = (req, res) => {
  const id = req.params.id;

  User.update(req.body, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "El usuario fue actualizado exitosamente."
        });
      } else {
        res.send({
          message: `No se pudo actualizar el usuario con id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error al actualizar el usuario con id=" + id
      });
    });
};

// Eliminar un usuario por su ID
exports.deleteUserById = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "El usuario fue eliminado exitosamente."
        });
      } else {
        res.send({
          message: `No se pudo eliminar el usuario con id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error al eliminar el usuario con id=" + id
      });
    });
};