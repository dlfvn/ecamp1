const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const User = sequelize.define('users', {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notNull: {
          msg: 'El nombre es obligatorio'
        },
        notEmpty: {
          msg: 'El nombre no puede estar vacío'
        }
      }
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notNull: {
          msg: 'El apellido es obligatorio'
        },
        notEmpty: {
          msg: 'El apellido no puede estar vacío'
        }
      }
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        notNull: {
          msg: 'El correo electrónico es obligatorio'
        },
        notEmpty: {
          msg: 'El correo electrónico no puede estar vacío'
        },
        isEmail: {
          msg: 'El correo electrónico debe tener un formato válido'
        }
      }
    },
  },
  {
    timestamps: true, // Agrega automáticamente createdAt y updatedAt
  });

  return User;
};