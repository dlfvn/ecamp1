const Sequelize = require('sequelize');
const dbConfig = require('../config/db.config.js');
const UserModel = require('./user.model.js');
const BootcampModel = require('./bootcamp.model.js');

const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  dialect: dbConfig.dialect,
  port: dbConfig.port,
  pool: {
    max: dbConfig.pool.max,
    min: dbConfig.pool.min,
    acquire: dbConfig.pool.acquire,
    idle: dbConfig.pool.idle,
  },
});

const User = UserModel(sequelize, Sequelize);
const Bootcamp = BootcampModel(sequelize, Sequelize);

// Define la relación muchos a muchos
User.belongsToMany(Bootcamp, {
  through: 'user_bootcamp',
  as: 'bootcamps',
  foreignKey: 'user_id',
});

Bootcamp.belongsToMany(User, {
  through: 'user_bootcamp',
  as: 'users',
  foreignKey: 'bootcamp_id',
});

module.exports = {
  Sequelize,
  sequelize,
  User,
  Bootcamp,
};