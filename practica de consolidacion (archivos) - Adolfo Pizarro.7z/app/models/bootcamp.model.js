const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Bootcamp = sequelize.define('bootcamps', {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notNull: {
          msg: 'El título es obligatorio'
        },
        notEmpty: {
          msg: 'El título no puede estar vacío'
        }
      }
    },
    cue: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        notNull: {
          msg: 'El CUE es obligatorio'
        },
        min: {
          args: [5],
          msg: 'El CUE debe ser como mínimo 5'
        },
        max: {
          args: [10],
          msg: 'El CUE debe ser como máximo 10'
        }
      }
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        notNull: {
          msg: 'La descripción es obligatoria'
        },
        notEmpty: {
          msg: 'La descripción no puede estar vacía'
        }
      }
    },
  },
  {
    timestamps: true,
  });

  return Bootcamp;
};