const db = require("./app/models");
const User = db.User;
const Bootcamp = db.Bootcamp;

async function main() {
  try {
    // Sincronizar los modelos con la base de datos
    await db.sequelize.sync({ force: true });
    console.log('Eliminando y resincronizando la base de datos.');

    // Crear usuarios
    const user1 = await User.create({
      firstName: "Mateo",
      lastName: "Díaz",
      email: "mateo.diaz@correo.com",
    });
    const user2 = await User.create({
      firstName: "Santiago",
      lastName: "Mejías",
      email: "santiago.mejias@correo.com",
    });
    const user3 = await User.create({
      firstName: "Lucas",
      lastName: "Rojas",
      email: "lucas.rojas@correo.com",
    });
    const user4 = await User.create({
      firstName: "Facundo",
      lastName: "Fernandez",
      email: "facundo.fernandez@correo.com",
    });

    // Crear Bootcamps
    const bootcamp1 = await Bootcamp.create({
      title: "Introduciendo El Bootcamp De React.",
      cue: 10,
      description: "React es la librería más usada en JavaScript para el desarrollo de interfaces.",
    });
    const bootcamp2 = await Bootcamp.create({
      title: "Bootcamp Desarrollo Web Full Stack.",
      cue: 10, 
      description: "Crearás aplicaciones web utilizando las tecnologías y lenguajes más actuales y populares, como: JavaScript, nodeJS, Angular, MongoDB, ExpressJS.",
    });
    const bootcamp3 = await Bootcamp.create({
      title: "Bootcamp Big Data, Inteligencia Artificial & Machine Learning.",
      cue: 10, 
      description: "Domina Data Science, y todo el ecosistema de lenguajes y herramientas de Big Data, e intégralos con modelos avanzados de Artificial Intelligence y Machine Learning.",
    });

    // Asociar usuarios a Bootcamps
    await bootcamp1.addUser(user1);
    await bootcamp1.addUser(user2);
    await bootcamp2.addUser(user1);
    await bootcamp3.addUser(user1);
    await bootcamp3.addUser(user2);
    await bootcamp3.addUser(user3);

    console.log("Usuarios y Bootcamps creados y asociados exitosamente.");

    // Consultas:

    // 1. Consultar un Bootcamp por ID, incluyendo sus usuarios.
    console.log("\nConsultando Bootcamp por ID (1), incluyendo usuarios:");
    const bootcampById = await Bootcamp.findByPk(1, {
      include: [
        {
          model: User,
          as: "users",
          attributes: ["id", "firstName", "lastName"],
          through: { attributes: [] }, // No mostrar atributos de la tabla intermedia
        },
      ],
    });
    console.log(JSON.stringify(bootcampById, null, 2));

    // 2. Listar todos los Bootcamps con sus usuarios.
    console.log("\nListando todos los Bootcamps con sus usuarios:");
    const allBootcamps = await Bootcamp.findAll({
      include: [
        {
          model: User,
          as: "users",
          attributes: ["id", "firstName", "lastName"],
          through: { attributes: [] },
        },
      ],
    });
    console.log(JSON.stringify(allBootcamps, null, 2));

    // 3. Consultar un usuario por ID, incluyendo sus Bootcamps.
    console.log("\nConsultando usuario por ID (1), incluyendo Bootcamps:");
    const userById = await User.findByPk(1, {
      include: [
        {
          model: Bootcamp,
          as: "bootcamps",
          attributes: ["id", "title"],
          through: { attributes: [] },
        },
      ],
    });
    console.log(JSON.stringify(userById, null, 2));

    // 4. Listar todos los usuarios con sus Bootcamps.
    console.log("\nListando todos los usuarios con sus Bootcamps:");
    const allUsers = await User.findAll({
      include: [
        {
          model: Bootcamp,
          as: "bootcamps",
          attributes: ["id", "title"],
          through: { attributes: [] },
        },
      ],
    });
    console.log(JSON.stringify(allUsers, null, 2));

    // 5. Actualizar un usuario por ID (ejemplo: actualizar el usuario con id=1 a 'Pedro Sánchez').
    console.log("\nActualizando usuario con ID 1 a 'Pedro Sánchez':");
    await User.update(
      { firstName: "Pedro", lastName: "Sánchez" },
      { where: { id: 1 } }
    );
    const updatedUser = await User.findByPk(1);
    console.log(JSON.stringify(updatedUser, null, 2));

    // 6. Eliminar un usuario por ID (ejemplo: eliminar el usuario con id=1).
    console.log("\nEliminando usuario con ID 1:");
    const deletedUserCount = await User.destroy({ where: { id: 1 } });
    console.log(`Usuarios eliminados: ${deletedUserCount}`);

    // Listar todos los usuarios para verificar la eliminación
    console.log("\nListando todos los usuarios después de la eliminación:");
    const remainingUsers = await User.findAll();
    console.log(JSON.stringify(remainingUsers, null, 2));
  } catch (error) {
    console.error("Error:", error);
  } finally {
    // Cierra la conexión a la base de datos
    await db.sequelize.close();
  }
}

main();