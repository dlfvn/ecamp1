require("dotenv").config();
const express = require("express");


const bodyParser = require('body-parser');
const cors = require('cors')


const {db, connect} = require("./app/config/db.config");
connect();

const app = express();


var corsOpt = {
    origin: '*', 
    optionsSuccessStatus: 200 
}
app.use(cors(corsOpt));


app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.json());


const authConfig = require('./app/config/auth.config');


const route = require('./app/routes')
app.use('/api', route)


app.get("/", (req, res) => {
    res.json({ message: "¡Bienvenido a la API bootcamp!" });
});


require('./app/routes/user.routes')(app);

require('./app/routes/bootcamp.routes')(app)

module.exports = app;