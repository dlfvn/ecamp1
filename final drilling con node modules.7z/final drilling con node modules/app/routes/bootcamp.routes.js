const { authJwt } = require("../middleware");
const controller = require("../controllers/bootcamp.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, Content-Type, Accept"
    );
    next();
  });

  app.post("/api/bootcamp", [authJwt.verifyToken], controller.createBootcamp);

  app.post("/api/bootcamp/adduser", [authJwt.verifyToken], controller.addUser);

  app.get("/api/bootcamp/:id", [authJwt.verifyToken], controller.findById);

  app.get("/api/bootcamp", controller.findAll);
};