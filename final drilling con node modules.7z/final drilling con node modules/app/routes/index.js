const express = require('express')
const router = express.Router()
const users = require('./user.routes')
const bootcamps = require('./bootcamp.routes')

router.use('/users', users)
router.use('/bootcamps', bootcamps)

module.exports = router