module.exports = {
    secret: process.env.TOKEN_KEY
  };