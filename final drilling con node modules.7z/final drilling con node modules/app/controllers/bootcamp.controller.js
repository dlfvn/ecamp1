const {
  users,
  bootcamps
} = require('../models')
const db = require('../models')
const Bootcamp = db.bootcamps
const User = db.users
const Op = db.Sequelize.Op;


exports.createBootcamp = async (req, res) => {
  try {
    const { title, cue, description } = req.body;

    if (!(title && cue && description)) {
      return res.status(400).send("Todos los campos son requeridos");
    }

    const bootcamp = await Bootcamp.create({
      title,
      cue,
      description,
    });

    return res.status(201).json(bootcamp);
  } catch (err) {
    console.error(err);
    return res.status(500).send("Error al crear el Bootcamp");
  }
};

exports.addUser = async (req, res) => {
  try {
    const { bootcampId, userId } = req.body;

    const bootcamp = await Bootcamp.findByPk(bootcampId);
    if (!bootcamp) {
      return res.status(404).send("Bootcamp no encontrado");
    }

    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).send("Usuario no encontrado");
    }

    await bootcamp.addUser(user);
    return res.status(200).send("Usuario agregado al Bootcamp exitosamente");
  } catch (err) {
    console.error(err);
    return res.status(500).send("Error al agregar usuario al Bootcamp");
  }
};


exports.findById = async (req, res) => {
  try {
    const { id } = req.params;
    const bootcamp = await Bootcamp.findByPk(id, {
      include: [{
        model: User,
        as: "users",
        attributes: ["id", "firstName", "lastName"],
        through: {
          attributes: [],
        }
      }],
    });

    if (!bootcamp) {
      return res.status(404).send("Bootcamp no encontrado");
    }

    return res.status(200).json(bootcamp);
  } catch (err) {
    console.error(err);
    return res.status(500).send("Error al obtener el Bootcamp");
  }
};

exports.findAll = async (req, res) => {
  try {
    const bootcamps = await Bootcamp.findAll({
      include: [{
        model: User,
        as: "users",
        attributes: ["id", "firstName", "lastName"],
        through: {
          attributes: [],
        }
      }],
    });

    return res.status(200).json(bootcamps);
  } catch (err) {
    console.error(err);
    return res.status(500).send("Error al obtener los Bootcamps");
  }
};