const {
  users
} = require('../models')
const db = require('../models')
const User = db.users
const Bootcamp = db.bootcamps
const Op = db.Sequelize.Op;
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");

exports.createUser = async (req, res) => {
  try {

      const { first_name, last_name, email, password } = req.body;
  

      if (!(email && password && first_name && last_name)) {
      return res.status(400).send("Todos los campos son requeridos");
      }

      encryptedPassword = await bcrypt.hash(password, 10);
  

      console.log("\nPassword encriptado: " + encryptedPassword);
  
   
      const user = await User.create({
      first_name,
      last_name,
      email: email.toLowerCase(), 
      password: encryptedPassword,
      });
  

      const token = jwt.sign(
      { user_id: user._id, email },
      config.secret,
      {
          expiresIn: "1h",
      }
      );
  
      user.token = token;
  
      return res.status(201).json(user); 
  } catch (err) {
      console.log(err);
      return res.status(500).send("Error al crear el usuario"); 
  }
  };


exports.findUserById = (req, res) => {
  const id = req.params.id;

  User.findByPk(id, {
    include: [{
      model: Bootcamp,
      as: "bootcamps",
      attributes: ["id", "title"],
      through: {
        attributes: [],
      }
    }],
  })
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({
          message: `No se puede encontrar el usuario con id=${id}.`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error al obtener el usuario con id=" + id
      });
    });
};


exports.findAll = (req, res) => {
  return User.findAll({
    include: [{
      model: Bootcamp,
      as: "bootcamps",
      attributes: ["id", "title"],
      through: {
        attributes: [],
      }
    }],
  }).then(users => {
    res.status(200).json(users)
  })
}


exports.updateUserById = (req, res) => {
  const id = req.params.id;

  User.update(req.body, {
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "El usuario ha sido actualizado exitosamente."
        });
      } else {
        res.send({
          message: `No se pudo actualizar el usuario con id=${id}.!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error actualizando el usuario con id=" + id
      });
    });
}


exports.deleteUserById = (req, res) => {
  const id = req.params.id;

  User.destroy({
    where: { id: id }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "El usuario fue eliminado correctamente!"
        });
      } else {
        res.send({
          message: `No se pudo eliminar el usuario con id=${id}!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error al eliminar el usuario con id=" + id
      });
    });
};


exports.signIn = async (req, res) => {
  try {

    const { email, password } = req.body;


    if (!(email && password)) {
      return res.status(400).send("Todos los campos son requeridos");
    }


    const user = await User.findOne({ where: { email } });

    if (user && (await bcrypt.compare(password, user.password))) {

      const token = jwt.sign(
        { user_id: user._id, email },
        config.secret,
        {
          expiresIn: "1h",
        }
      );


      user.token = token;


      return res.status(200).json(user);
    }
    return res.status(400).send("Credenciales inválidas");
  } catch (err) {
    console.log(err);
    return res.status(500).send("Error al iniciar sesión");
  }
};