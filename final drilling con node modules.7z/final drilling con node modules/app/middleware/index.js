const authJwt = require("./auth");
const verifySignUp = require("./verifySingUp");

module.exports = {
authJwt,
verifySignUp
};