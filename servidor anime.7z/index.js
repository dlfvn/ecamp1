const express = require('express');
const fs = require('fs').promises;
const app = express();
const port = 3000;

// Middleware para parsear el body de las peticiones en formato JSON
app.use(express.json());

// Función auxiliar para leer el archivo anime.json
async function leerAnimes() {
  try {
    const data = await fs.readFile('./anime.json', 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error al leer el archivo anime.json:', error);
    return {}; // Devolver un objeto vacío en caso de error
  }
}

// GET /animes - Listar todos los animes
app.get('/animes', async (req, res) => {
  const animes = await leerAnimes();
  res.json(animes);
});

// GET /animes/:id - Obtener un anime por su ID
app.get('/animes/:id', async (req, res) => {
  const animes = await leerAnimes();
  const id = req.params.id;
  if (animes[id]) {
    res.json(animes[id]);
  } else {
    res.status(404).send('Anime no encontrado');
  }
});

// GET /animes - Obtener un anime por su nombre (query parameter)
app.get('/animes', async (req, res) => {
  const animes = await leerAnimes();
  const nombre = req.query.nombre;
  if (nombre) {
    const animeEncontrado = Object.values(animes).find(anime => anime.nombre.toLowerCase() === nombre.toLowerCase());
    if (animeEncontrado) {
      res.json(animeEncontrado);
    } else {
      res.status(404).send('Anime no encontrado');
    }
  } else {
    // Si no se proporciona el parámetro 'nombre', se listan todos los animes (ya implementado)
    res.json(animes); 
  }
});

// POST /animes - Crear un nuevo anime
app.post('/animes', async (req, res) => {
  const animes = await leerAnimes();
  const nuevoAnime = req.body;
  
  // Generar un ID único (podrías usar una librería como uuid aquí)
  const nuevoId = (Math.max(...Object.keys(animes).map(Number)) + 1).toString();

  animes[nuevoId] = nuevoAnime;
  await fs.writeFile('./anime.json', JSON.stringify(animes, null, 2));
  res.status(201).json(nuevoAnime);
});

// PUT /animes/:id - Actualizar un anime existente
app.put('/animes/:id', async (req, res) => {
  const animes = await leerAnimes();
  const id = req.params.id;
  const datosActualizados = req.body;

  if (animes[id]) {
    animes[id] = { ...animes[id], ...datosActualizados };
    await fs.writeFile('./anime.json', JSON.stringify(animes, null, 2));
    res.json(animes[id]);
  } else {
    res.status(404).send('Anime no encontrado');
  }
});

// DELETE /animes/:id - Eliminar un anime
app.delete('/animes/:id', async (req, res) => {
  const animes = await leerAnimes();
  const id = req.params.id;

  if (animes[id]) {
    delete animes[id];
    await fs.writeFile('./anime.json', JSON.stringify(animes, null, 2));
    res.status(204).send();
  } else {
    res.status(404).send('Anime no encontrado');
  }
});

app.listen(port, () => {
  console.log(`Servidor escuchando en el puerto ${port}`);
});